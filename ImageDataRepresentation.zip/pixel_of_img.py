# pixel of image - I Putu Windy Arya Sagita - 5027201071
import cv2

img = cv2.imread('img_lights.jpg')

print(img.shape)

print(img)
